#include <stdio.h>

int main () {
  printf("Helooooooo nurse! :)\n");
}
